import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { FormsModule} from '@angular/forms';

import { AppComponent }  from './app.component';
import { HeaderComponent }  from './header/header.component';
import { ContentComponent }  from './content/content.component';
import { ShoesList } from './shoes-list/shoes-list.component';
import { FooterComponent } from './footer/footer.component';
import { ContactPage } from './contactpage/contactpage.component';
import { DetailPage } from './detailspage/detailspage.component';





@NgModule({
  imports:      [ BrowserModule, FormsModule,
  RouterModule.forRoot([
  { path: 'home', component: ContentComponent },
  { path: 'contact', component: ContactPage },
  { path: 'detail', component: DetailPage },
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: '**', redirectTo: 'home', pathMatch: 'full' }
  ]), ],
  declarations: [ AppComponent, HeaderComponent, ContentComponent, ShoesList, FooterComponent, ContactPage, DetailPage,],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
