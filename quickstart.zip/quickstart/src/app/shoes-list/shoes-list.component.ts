import { Component } from '@angular/core';

@Component({
	selector: "shoes",
	template: `
		<section class="shoes">
		<div id="item-container" *ngFor="let recipe of recipes" class="recipe" style="background-color: white;">
			<div>*****</div>
			<img id="item-picture" src="{{recipe.image}}">
			<h5 class="margin-l-r">{{recipe.name|uppercase}}</h5>
			<b><h6 class="margin-l-r">{{recipe.type|uppercase}}</h6></b>
			<h6 class="margin-l-r">{{recipe.description}}</h6>
			<h6 id="price">{{recipe.price}}</h6>
			<div id="buy-now-container">
			<button id="buy-now">BUY NOW</button>
			</div>
		</div>
		</section>
	`
})
export class ShoesList {
	recipes: any = [{
		id: 1,
		image: "../../img/shoe-item.jpg",
		name: "Gel-fujitrabuco 5 G-TX",
		type: "Running Shoe",
		description: "5 G-TX has proven to be one of the most succesfull shoes to ever walk on this earth, Even Shikira loves them. Perfect for excersizing ",
		price:"£ 86.99" 
	}];
}