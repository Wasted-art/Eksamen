"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var ShoesList = (function () {
    function ShoesList() {
        this.recipes = [{
                id: 1,
                image: "../../img/shoe-item.jpg",
                name: "Gel-fujitrabuco 5 G-TX",
                type: "Running Shoe",
                description: "5 G-TX has proven to be one of the most succesfull shoes to ever walk on this earth, Even Shikira loves them. Perfect for excersizing ",
                price: "£ 86.99"
            }];
    }
    ShoesList = __decorate([
        core_1.Component({
            selector: "shoes",
            template: "\n\t\t<section class=\"shoes\">\n\t\t<div id=\"item-container\" *ngFor=\"let recipe of recipes\" class=\"recipe\" style=\"background-color: white;\">\n\t\t\t<div>*****</div>\n\t\t\t<img id=\"item-picture\" src=\"{{recipe.image}}\">\n\t\t\t<h5 class=\"margin-l-r\">{{recipe.name|uppercase}}</h5>\n\t\t\t<b><h6 class=\"margin-l-r\">{{recipe.type|uppercase}}</h6></b>\n\t\t\t<h6 class=\"margin-l-r\">{{recipe.description}}</h6>\n\t\t\t<h6 id=\"price\">{{recipe.price}}</h6>\n\t\t\t<div id=\"buy-now-container\">\n\t\t\t<button id=\"buy-now\">BUY NOW</button>\n\t\t\t</div>\n\t\t</div>\n\t\t</section>\n\t"
        }), 
        __metadata('design:paramtypes', [])
    ], ShoesList);
    return ShoesList;
}());
exports.ShoesList = ShoesList;
//# sourceMappingURL=shoes-list.component.js.map