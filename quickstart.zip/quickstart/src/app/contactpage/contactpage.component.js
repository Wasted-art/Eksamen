"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var Newsletter = (function () {
    function Newsletter() {
    }
    return Newsletter;
}());
var ContactPage = (function () {
    function ContactPage() {
        this.model = new Newsletter();
        this.hasBeenSubmitted = false;
    }
    ContactPage.prototype.ngOnInit = function () {
        this.newsdropdown = ['Baking', 'Dinners', 'Starters'];
        this.hasBeenSubmitted = false;
    };
    ContactPage.prototype.register = function (form, event) {
        event.preventDefault();
        // saves the data to the api
        this.hasBeenSubmitted = true;
    };
    ContactPage = __decorate([
        core_1.Component({
            selector: 'contact-page',
            template: "\n\t\t<div class=\"form-placeholder-container\">\n\t\t\t<div class=\"form-container\">\t\n\t\t\t\t<div [hidden]=\"hasBeenSubmitted\">\n\t\t\t\t\t<form (ngSubmit)=\"register(newsletterForm, $event)\" #newsletterForm=\"ngForm\" novalidate>\n\t\t\t\t\t\t<div>\n\t\t\t\t\t\t\t<label for=\"contactname\">Name</label>\n\t\t\t\t\t\t\t<input type=\"text\" id=\"contactname\" name=\"model.contactname\" [(ngModel)]=\"model.contactname\" required />\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div>\n\t\t\t\t\t\t\t<label for=\"contactemail\">Email</label>\n\t\t\t\t\t\t\t<input type=\"text\" id=\"contactemail\" name=\"contactemail\" [(ngModel)]=\"model.contactemail\" pattern=\"\" />\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div>\n\t\t\t\t\t\t\t<label for=\"newstype\">Newstype</label>\n\t\t\t\t\t\t\t<select [(ngModel)]=\"model.newstype\" name=\"newstype\">\n\t\t\t\t\t\t\t\t<option *ngFor=\"let item of newsdropdown\" [value]=\"item\">{{item}}</option>\n\t\t\t\t\t\t\t</select>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<button type=\"submit\">Submit request</button>\n\t\t\t\t\t</form>\n\t\t\t\t</div>\n\t\t\t\t<div [hidden]=\"!hasBeenSubmitted\"> Thanks for submitting {{model.contactname}}.\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\n\t"
        }), 
        __metadata('design:paramtypes', [])
    ], ContactPage);
    return ContactPage;
}());
exports.ContactPage = ContactPage;
//# sourceMappingURL=contactpage.component.js.map