import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';

class Newsletter{
	contactname: string;
	contactemail: string;
	newstype: string;
}

@Component ({
	selector: 'contact-page',
	template:`
		<div class="form-placeholder-container">
			<div class="form-container">	
				<div [hidden]="hasBeenSubmitted">
					<form (ngSubmit)="register(newsletterForm, $event)" #newsletterForm="ngForm" novalidate>
						<div>
							<label for="contactname">Name</label>
							<input type="text" id="contactname" name="model.contactname" [(ngModel)]="model.contactname" required />
						</div>
						<div>
							<label for="contactemail">Email</label>
							<input type="text" id="contactemail" name="contactemail" [(ngModel)]="model.contactemail" pattern="" />
						</div>
						<div>
							<label for="newstype">Newstype</label>
							<select [(ngModel)]="model.newstype" name="newstype">
								<option *ngFor="let item of newsdropdown" [value]="item">{{item}}</option>
							</select>
						</div>
						<button type="submit">Submit request</button>
					</form>
				</div>
				<div [hidden]="!hasBeenSubmitted"> Thanks for submitting {{model.contactname}}.
				</div>
			</div>
		</div>

	`
})
export class ContactPage implements OnInit {
	model:Newsletter = new Newsletter();
	newsdropdown: Array<string>;
	hasBeenSubmitted = false;

	ngOnInit() {
		this.newsdropdown = ['Baking', 'Dinners', 'Starters'];
		this.hasBeenSubmitted = false;
	}

	register(form:NgForm, event:Event) {
		event.preventDefault();
		// saves the data to the api
		this.hasBeenSubmitted = true;
	}
}