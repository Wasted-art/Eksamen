"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var RecipeListComponent = (function () {
    function RecipeListComponent() {
        this.recipes = [{
                id: 1,
                name: "Strawberry Tart",
                description: "Make the best Strawberry ever",
                method: "Blablabla",
                ingredients: ["250g flour", "100g Butter", "400g Strawberries"],
                image: "app/img/dummy.jpg",
                preptime: 40,
                cookingtime: 60
            }, {
                id: 2,
                name: "Shoes",
                description: "Make the best Strawberry ever test",
                method: "Blablabla test",
                ingredients: ["250g flour test", "100g Butter test", "400g Strawberries test"],
                image: "./img/shoe.png",
                preptime: 40,
                cookingtime: 60
            }];
    }
    RecipeListComponent = __decorate([
        core_1.Component({
            selector: "recipe-list",
            template: "\n\t\t<section class=\"recipe-list\">\n\t\t\t<div *ngFor= \"let recipe of recipes\" class=\"recipe\">\n\t\t\t\t<h2>{{recipe.name}} </h2>\n\t\t\t\t<img src=\"{{recipe.image}}\" />\n\t\t\t\t<p> {{recipe.description}} </p>\n\t\t\t</div>\n\t\t</section>\n\t"
        }), 
        __metadata('design:paramtypes', [])
    ], RecipeListComponent);
    return RecipeListComponent;
}());
exports.RecipeListComponent = RecipeListComponent;
//# sourceMappingURL=recipe-list.component.js.map