import { Component } from '@angular/core';

@Component ({
	selector: 'footercomponent',
	template:`
		<div class="footer-top-container">
			<div class="top-footer-l">
				<h5 class="center-l">SIGN UP FOR EXCLUSIVE SALES AND PRODUCT NEWS</h5>
			</div>
			<div class="top-footer-R" >
				<input class="footer-input" value="Christian@gundersen.dk" type="" name="">
				<button class="footer-button" >SIGN UP</button>
			</div>
		</div>
		<div class="footer-button-container">
			<div class="footer-info-container">
				<div class="footer-rows">
					<h5 class="footer-gray-font">
						<span class="footer-white-font">OUR STORES</span>
						<br>
						<br>
						Feel free to visit our stores or contact us.
						<br>
						<br>
						Vinegade 109
						<br>
						5000 Odense
						<br>
						99886622
						<br>
						<br>
						Vestergade 910
						<br>
						9000 Aalborg
						<br>
						96819191
						<br>
					</h5>
				</div>
				<div class="footer-rows">
					<h5 class="footer-gray-font">
						<span class="footer-white-font">BLOG POST</span>
						<br>
						<br>
						<span class="footer-white-font">FAQ</span>
						<br>
						Hvor mange vafler kan man spise på en time?
						<br>
						Hva' sker der for lakse tema?!
						<br>
						<br>
						<span class="footer-white-font">New sexy sports wear</span>
						<br>
						The new sexy starwars themed sports serie,
						<br>
						on sale!
						<br>
						<br>
						<span class="footer-white-font">Summer sales are coming!</span>
						<br>
						We have been working our sweet behinds off
						<br>
						in order to make the Summer sales reality
					</h5>
				</div>
				<div class="footer-rows-half">
					<h5 class="footer-gray-font">
						<span class="footer-white-font">SUPPORT</span>
						<br>
						<br>
						Termns & Conditions
						<br>
						Payment
						<br>
						Refunds
						<br>
						Track Order
						<br>
						Services
						<br>
						Privacy & Security
						<br>
						Careers
						<br>
						Press
						<br>
						Corporate Information
						<br>
					</h5>
				</div>
				<div class="footer-rows-half">
					<h5 class="footer-gray-font">
						<span class="footer-white-font"></span>
						<br>
						<br>
						Sizing
						<br>
						Ordering
						<br>
						Shipping
						<br>
						Return Policy
						<br>
						Find Store
						<br>
						Site Map
						<br>
						Sign Up & Save
						<br>
					</h5>
				</div>
			</div>
		</div>
	`
})
export class FooterComponent {}