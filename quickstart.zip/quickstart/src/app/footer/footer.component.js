"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var FooterComponent = (function () {
    function FooterComponent() {
    }
    FooterComponent = __decorate([
        core_1.Component({
            selector: 'footercomponent',
            template: "\n\t\t<div class=\"footer-top-container\">\n\t\t\t<div class=\"top-footer-l\">\n\t\t\t\t<h5 class=\"center-l\">SIGN UP FOR EXCLUSIVE SALES AND PRODUCT NEWS</h5>\n\t\t\t</div>\n\t\t\t<div class=\"top-footer-R\" >\n\t\t\t\t<input class=\"footer-input\" value=\"Christian@gundersen.dk\" type=\"\" name=\"\">\n\t\t\t\t<button class=\"footer-button\" >SIGN UP</button>\n\t\t\t</div>\n\t\t</div>\n\t\t<div class=\"footer-button-container\">\n\t\t\t<div class=\"footer-info-container\">\n\t\t\t\t<div class=\"footer-rows\">\n\t\t\t\t\t<h5 class=\"footer-gray-font\">\n\t\t\t\t\t\t<span class=\"footer-white-font\">OUR STORES</span>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tFeel free to visit our stores or contact us.\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tVinegade 109\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t5000 Odense\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t99886622\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tVestergade 910\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t9000 Aalborg\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t96819191\n\t\t\t\t\t\t<br>\n\t\t\t\t\t</h5>\n\t\t\t\t</div>\n\t\t\t\t<div class=\"footer-rows\">\n\t\t\t\t\t<h5 class=\"footer-gray-font\">\n\t\t\t\t\t\t<span class=\"footer-white-font\">BLOG POST</span>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t<span class=\"footer-white-font\">FAQ</span>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tHvor mange vafler kan man spise p\u00E5 en time?\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tHva' sker der for lakse tema?!\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t<span class=\"footer-white-font\">New sexy sports wear</span>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tThe new sexy starwars themed sports serie,\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\ton sale!\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t<span class=\"footer-white-font\">Summer sales are coming!</span>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tWe have been working our sweet behinds off\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tin order to make the Summer sales reality\n\t\t\t\t\t</h5>\n\t\t\t\t</div>\n\t\t\t\t<div class=\"footer-rows-half\">\n\t\t\t\t\t<h5 class=\"footer-gray-font\">\n\t\t\t\t\t\t<span class=\"footer-white-font\">SUPPORT</span>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tTermns & Conditions\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tPayment\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tRefunds\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tTrack Order\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tServices\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tPrivacy & Security\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tCareers\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tPress\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tCorporate Information\n\t\t\t\t\t\t<br>\n\t\t\t\t\t</h5>\n\t\t\t\t</div>\n\t\t\t\t<div class=\"footer-rows-half\">\n\t\t\t\t\t<h5 class=\"footer-gray-font\">\n\t\t\t\t\t\t<span class=\"footer-white-font\"></span>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tSizing\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tOrdering\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tShipping\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tReturn Policy\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tFind Store\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tSite Map\n\t\t\t\t\t\t<br>\n\t\t\t\t\t\tSign Up & Save\n\t\t\t\t\t\t<br>\n\t\t\t\t\t</h5>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t"
        }), 
        __metadata('design:paramtypes', [])
    ], FooterComponent);
    return FooterComponent;
}());
exports.FooterComponent = FooterComponent;
//# sourceMappingURL=footer.component.js.map