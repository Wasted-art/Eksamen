import { Component } from '@angular/core';
import { ShoesList } from '../shoes-list/shoes-list.component';

@Component ({
	selector: 'detailpage',
	template:`
		<div class="details-container" style="background-color: white;">
			<div class="detail-content-container" style="background-color: white;">
				<div class="detail-content-container-l" style="background-color: white;">
					<div class="shoe-picture-big">
						<img class="bigshoe" src="../../img/shoe-big.jpg">	
					</div>
					<div class="small-pictures-container">
						<div class="shoe-picture-small">
							<img class="smallshoe" src="../../img/shoe 3.jpg">		
						</div>		
						<div class="shoe-picture-small">
							<img class="smallshoe" src="../../img/shoe-1.jpg">		
						</div>
						<div class="shoe-picture-small">
							<img class="smallshoe" src="../../img/shoe 2.jpg">		
						</div>	
					</div>	
				</div>

				<div class="detail-content-container-r" style="background-color: white;">
					<h5 class="name-l">Gel-fujitrabuco 5 G-TX</h5>
					<div class="place-holder-r">
						<div class="name-price-container" style="background-color: white;">
							<img class="logo-l" src="../../img/brand logo.jpg" height="67px" width="162px">
							<h3 class="price-r">kr 947.90</h3>
						</div>
					</div>
					<button class="detail-button">BUY NOW</button>
				</div>
			</div>
		</div>
	`
})
export class DetailPage {
		recipes: any = [{
		id: 1,
		image: "../../img/shoe-item.jpg",
		name: "Gel-fujitrabuco 5 G-TX",
		type: "Running Shoe",
		description: "5 G-TX has proven to be one of the most succesfull shoes to ever walk on this earth, Even Shikira loves them. Perfect for excersizing ",
		price:"£ 86.99" 
	}];
}