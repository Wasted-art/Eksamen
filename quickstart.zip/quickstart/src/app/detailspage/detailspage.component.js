"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var DetailPage = (function () {
    function DetailPage() {
        this.recipes = [{
                id: 1,
                image: "../../img/shoe-item.jpg",
                name: "Gel-fujitrabuco 5 G-TX",
                type: "Running Shoe",
                description: "5 G-TX has proven to be one of the most succesfull shoes to ever walk on this earth, Even Shikira loves them. Perfect for excersizing ",
                price: "£ 86.99"
            }];
    }
    DetailPage = __decorate([
        core_1.Component({
            selector: 'detailpage',
            template: "\n\t\t<div class=\"details-container\" style=\"background-color: white;\">\n\t\t\t<div class=\"detail-content-container\" style=\"background-color: white;\">\n\t\t\t\t<div class=\"detail-content-container-l\" style=\"background-color: white;\">\n\t\t\t\t\t<div class=\"shoe-picture-big\">\n\t\t\t\t\t\t<img class=\"bigshoe\" src=\"../../img/shoe-big.jpg\">\t\n\t\t\t\t\t</div>\n\t\t\t\t\t<div class=\"small-pictures-container\">\n\t\t\t\t\t\t<div class=\"shoe-picture-small\">\n\t\t\t\t\t\t\t<img class=\"smallshoe\" src=\"../../img/shoe 3.jpg\">\t\t\n\t\t\t\t\t\t</div>\t\t\n\t\t\t\t\t\t<div class=\"shoe-picture-small\">\n\t\t\t\t\t\t\t<img class=\"smallshoe\" src=\"../../img/shoe-1.jpg\">\t\t\n\t\t\t\t\t\t</div>\n\t\t\t\t\t\t<div class=\"shoe-picture-small\">\n\t\t\t\t\t\t\t<img class=\"smallshoe\" src=\"../../img/shoe 2.jpg\">\t\t\n\t\t\t\t\t\t</div>\t\n\t\t\t\t\t</div>\t\n\t\t\t\t</div>\n\n\t\t\t\t<div class=\"detail-content-container-r\" style=\"background-color: white;\">\n\t\t\t\t\t<h5 class=\"name-l\">Gel-fujitrabuco 5 G-TX</h5>\n\t\t\t\t\t<div class=\"place-holder-r\">\n\t\t\t\t\t\t<div class=\"name-price-container\" style=\"background-color: white;\">\n\t\t\t\t\t\t\t<img class=\"logo-l\" src=\"../../img/brand logo.jpg\" height=\"67px\" width=\"162px\">\n\t\t\t\t\t\t\t<h3 class=\"price-r\">kr 947.90</h3>\n\t\t\t\t\t\t</div>\n\t\t\t\t\t</div>\n\t\t\t\t\t<button class=\"detail-button\">BUY NOW</button>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t"
        }), 
        __metadata('design:paramtypes', [])
    ], DetailPage);
    return DetailPage;
}());
exports.DetailPage = DetailPage;
//# sourceMappingURL=detailspage.component.js.map