"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var HeaderComponent = (function () {
    function HeaderComponent() {
    }
    HeaderComponent = __decorate([
        core_1.Component({
            selector: 'headercomponent',
            template: "\n\t\t<div class=\"row\" id=\"row-header\">\n\t\t\t<div class=\"col s12 l12\" id=\"header-container\">\n\t\t\t\t<div class=\"col s1 l1\" id=\"headerleft\">\n\t\t\t\t</div>\n\t\t\t\t<div class=\"col s10 l10\" id=\"headermiddel\">\n\t\t\t\t\t<img class=\"col s4 l4\" id=\"logo\" src=\"img/SuperSPORTS.jpg\">\n\t\t\t\t\t<hr class=\"col s12 l12\">\n\t\t\t\t\t<ul  id=\"links\" class=\"col s9 l9\">\n\t\t\t\t\t\t<li><a [routerLink]=\"['home']\" class=\"links-hover\">HOME</a></li>\n\t\t\t\t\t\t<li><a [routerLink]=\"['contact']\" class=\"links-hover\">MEN</a></li>\n\t\t\t\t\t\t<li><a [routerLink]=\"['detail']\" class=\"links-hover\">WOMEN</a></li>\n\t\t\t\t\t\t<li><a class=\"links-hover\" href=\"http://wasted-art.deviantart.com/\" target=\"_blank\">KIDS</a></li>\n\t\t\t\t\t\t<li><a class=\"links-hover\" href=\"http://wasted-art.deviantart.com/\" target=\"_blank\">SALE</a></li>\n\t\t\t\t\t\t<li><a class=\"links-hover\" href=\"http://wasted-art.deviantart.com/\" target=\"_blank\">ABOUT US</a></li>\n\t\t\t\t\t\t<li><a class=\"links-hover\" href=\"http://wasted-art.deviantart.com/\" target=\"_blank\">SUPPORT</a></li>\n\t\t\t\t\t</ul>\n\t\t\t\t\t<div class=\"col s3 l3\" id=\"search\" >\n\t\t\t\t\t<img id=\"loop\" src=\"img/loop.gif\">\n\t\t\t\t\t\t<input id=\"search-input\" class=\"col s9 l9\" value=\"Search..\" type=\"text\">\n\t\t\t\t\t</div>\n\t\t\t</div>\t\n\t\t</div>\n\t\t<img class=\"col s12 l12\" id=\"bottom-style\" id=\"bottom-style\" src=\"img/headerstyle.png\">\n\n\t"
        }), 
        __metadata('design:paramtypes', [])
    ], HeaderComponent);
    return HeaderComponent;
}());
exports.HeaderComponent = HeaderComponent;
//# sourceMappingURL=header.component.js.map