import { Component } from '@angular/core';

@Component ({
	selector: 'headercomponent',
	template:`
		<div class="row" id="row-header">
			<div class="col s12 l12" id="header-container">
				<div class="col s1 l1" id="headerleft">
				</div>
				<div class="col s10 l10" id="headermiddel">
					<img class="col s4 l4" id="logo" src="img/SuperSPORTS.jpg">
					<hr class="col s12 l12">
					<ul  id="links" class="col s9 l9">
						<li><a [routerLink]="['home']" class="links-hover">HOME</a></li>
						<li><a [routerLink]="['contact']" class="links-hover">MEN</a></li>
						<li><a [routerLink]="['detail']" class="links-hover">WOMEN</a></li>
						<li><a class="links-hover" href="http://wasted-art.deviantart.com/" target="_blank">KIDS</a></li>
						<li><a class="links-hover" href="http://wasted-art.deviantart.com/" target="_blank">SALE</a></li>
						<li><a class="links-hover" href="http://wasted-art.deviantart.com/" target="_blank">ABOUT US</a></li>
						<li><a class="links-hover" href="http://wasted-art.deviantart.com/" target="_blank">SUPPORT</a></li>
					</ul>
					<div class="col s3 l3" id="search" >
					<img id="loop" src="img/loop.gif">
						<input id="search-input" class="col s9 l9" value="Search.." type="text">
					</div>
			</div>	
		</div>
		<img class="col s12 l12" id="bottom-style" id="bottom-style" src="img/headerstyle.png">

	`
})

export class HeaderComponent {}
