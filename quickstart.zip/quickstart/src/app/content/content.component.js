"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var ContentComponent = (function () {
    function ContentComponent() {
    }
    ContentComponent = __decorate([
        core_1.Component({
            selector: 'contentcomponent',
            template: "\n\t<div class=\"row\" id=\"slide-container\" style=\"background-color: pink;\">\n\t\t<div class=\"col s12 l12\" id=\"slide-show\">\n\t\t\t<div class=\"col s4 l4\" id=\"black-box\">\n\t\t\t\t<div id=\"trans-blok\"></div>\n\t\t\t\t<h1 id=\"h1-fontwhite\">RIGHT IS PINK.<br>LEFT IS BLUE</h1>\n\t\t\t\t<h6 id=\"h6-fontwhite\"> Inspired by Brasil's bold colors matching up to football's on-pitch<br>playmakers, these kicks are ready to stand out.</h6>\n\t\t\t\t<button class=\"button-style\">SHOP BRASIL</button>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\n\t<div id=\"categorys-container\">\n\t\t<div id=\"categorys-block\">\n\t\t\t<div id=\"categorys-items\">\n\t\t\t\t<div>\n\t\t\t\t\t<a href=\"http://wasted-art.deviantart.com/\" target=\"_blank\"><img id=\"shoes1\" src=\"../../img/shoes.jpg\"></a>\n\t\t\t\t\t<a class=\"categorys-hover\" href=\"http://wasted-art.deviantart.com/\" target=\"_blank\"><h4 class=\"categorys-h4\">FOOTBALL SHOES</h4></a>\n\t\t\t\t\t<h6 class=\"categorys-h6\">This shoes will ROCK you, beyound repair, becouse they are so Awesome, by the way this is made widt flex tags in sass.</h6>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t\t<div id=\"categorys-block\">\n\t\t\t<div id=\"categorys-items\">\n\t\t\t\t<div>\n\t\t\t\t\t<a href=\"http://wasted-art.deviantart.com/\" target=\"_blank\"><img id=\"shoes1\" src=\"../../img/clothes.jpg\"></a>\n\t\t\t\t\t<a class=\"categorys-hover\" href=\"http://wasted-art.deviantart.com/\" target=\"_blank\"><h4 class=\"categorys-h4\">MODERN CLOTHES</h4></a>\n\t\t\t\t\t<h6 class=\"categorys-h6\">This shoes will ROCK your world, beyound repair, becouse they are so Awesome, by the way this is made widt flex tags in sass.</h6>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t\t<div id=\"categorys-block\">\n\t\t\t<div id=\"categorys-items\">\n\t\t\t\t<div>\n\t\t\t\t\t<a href=\"http://wasted-art.deviantart.com/\" target=\"_blank\"><img id=\"shoes1\" src=\"../../img/bag.jpg\"></a>\n\t\t\t\t\t<a class=\"categorys-hover\" href=\"http://wasted-art.deviantart.com/\" target=\"_blank\"><h4 class=\"categorys-h4\">BAGS & ACCESSORIES</h4></a>\n\t\t\t\t\t<h6 class=\"categorys-h6\">This shoes will ROCK your world, beyound repair, becouse they are so Awesome, by the way this is made widt flex tags in sass.</h6>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n\n\t<div class=\"popular-block\">\n\t\t<h5 class=\"popular-font\">POPULAR PRODUCTS</h5>\n\t</div>\n\n\t<div id=\"placeholder\" style=\"background-color: white;\">\n\t    <shoes></shoes>\n\t    <shoes></shoes>\n\t    <shoes></shoes>\n\t    <shoes></shoes>\n    </div>\n    <div id=\"placeholder\" style=\"background-color: white;\">\n\t    <shoes></shoes>\n\t    <shoes></shoes>\n\t    <shoes></shoes>\n\t    <shoes></shoes>\n    </div>\n\t"
        }), 
        __metadata('design:paramtypes', [])
    ], ContentComponent);
    return ContentComponent;
}());
exports.ContentComponent = ContentComponent;
//# sourceMappingURL=content.component.js.map