import { Component } from '@angular/core';

@Component ({
	selector: 'contentcomponent',
	template:`
	<div class="row" id="slide-container" style="background-color: pink;">
		<div class="col s12 l12" id="slide-show">
			<div class="col s4 l4" id="black-box">
				<div id="trans-blok"></div>
				<h1 id="h1-fontwhite">RIGHT IS PINK.<br>LEFT IS BLUE</h1>
				<h6 id="h6-fontwhite"> Inspired by Brasil's bold colors matching up to football's on-pitch<br>playmakers, these kicks are ready to stand out.</h6>
				<button class="button-style">SHOP BRASIL</button>
			</div>
		</div>
	</div>

	<div id="categorys-container">
		<div id="categorys-block">
			<div id="categorys-items">
				<div>
					<a href="http://wasted-art.deviantart.com/" target="_blank"><img id="shoes1" src="../../img/shoes.jpg"></a>
					<a class="categorys-hover" href="http://wasted-art.deviantart.com/" target="_blank"><h4 class="categorys-h4">FOOTBALL SHOES</h4></a>
					<h6 class="categorys-h6">This shoes will ROCK you, beyound repair, becouse they are so Awesome, by the way this is made widt flex tags in sass.</h6>
				</div>
			</div>
		</div>
		<div id="categorys-block">
			<div id="categorys-items">
				<div>
					<a href="http://wasted-art.deviantart.com/" target="_blank"><img id="shoes1" src="../../img/clothes.jpg"></a>
					<a class="categorys-hover" href="http://wasted-art.deviantart.com/" target="_blank"><h4 class="categorys-h4">MODERN CLOTHES</h4></a>
					<h6 class="categorys-h6">This shoes will ROCK your world, beyound repair, becouse they are so Awesome, by the way this is made widt flex tags in sass.</h6>
				</div>
			</div>
		</div>
		<div id="categorys-block">
			<div id="categorys-items">
				<div>
					<a href="http://wasted-art.deviantart.com/" target="_blank"><img id="shoes1" src="../../img/bag.jpg"></a>
					<a class="categorys-hover" href="http://wasted-art.deviantart.com/" target="_blank"><h4 class="categorys-h4">BAGS & ACCESSORIES</h4></a>
					<h6 class="categorys-h6">This shoes will ROCK your world, beyound repair, becouse they are so Awesome, by the way this is made widt flex tags in sass.</h6>
				</div>
			</div>
		</div>
	</div>

	<div class="popular-block">
		<h5 class="popular-font">POPULAR PRODUCTS</h5>
	</div>

	<div id="placeholder" style="background-color: white;">
	    <shoes></shoes>
	    <shoes></shoes>
	    <shoes></shoes>
	    <shoes></shoes>
    </div>
    <div id="placeholder" style="background-color: white;">
	    <shoes></shoes>
	    <shoes></shoes>
	    <shoes></shoes>
	    <shoes></shoes>
    </div>
	`
}) 

export class ContentComponent {}