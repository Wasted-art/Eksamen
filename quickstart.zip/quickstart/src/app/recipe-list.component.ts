import { Component } from '@angular/core';

@Component({
	selector: "recipe-list",
	template:`
		<section class="recipe-list">
			<div *ngFor= "let recipe of recipes" class="recipe">
				<h2>{{recipe.name}} </h2>
				<img src="{{recipe.image}}" />
				<p> {{recipe.description}} </p>
			</div>
		</section>
	`
})

export class RecipeListComponent {
	recipes: any = [{
		id: 1,
		name: "Strawberry Tart",
		description:"Make the best Strawberry ever",
		method: "Blablabla",
		ingredients: ["250g flour", "100g Butter", "400g Strawberries"],
		image: "app/img/dummy.jpg",
		preptime: 40,
		cookingtime: 60
	},{
		id: 2,
		name: "Shoes",
		description:"Make the best Strawberry ever test",
		method: "Blablabla test",
		ingredients: ["250g flour test", "100g Butter test", "400g Strawberries test"],
		image: "./img/shoe.png",
		preptime: 40,
		cookingtime: 60
	}]
}